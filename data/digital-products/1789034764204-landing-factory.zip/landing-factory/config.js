// config.js — إعدادات مصنع صفحات الهبوط
// يمكنك تعديل هذا الملف لإضافة قوالب جديدة أو تعديل الحقول

const CONFIG = {
  appName: "مصنع صفحات الهبوط",
  version: "1.0.0",

  // القوالب المتاحة
  templates: [
    {
      id: "saas",
      name: "SaaS حديث",
      description: "مناسب للأدوات والتطبيقات التقنية",
      emoji: "🚀",
      color: "#6c63ff",
      file: "templates/template1.html",
      fields: [
        { key: "TITLE",       label: "عنوان الصفحة (Tab)",     type: "text",     placeholder: "أداتي الرائعة" },
        { key: "HERO_TITLE",  label: "العنوان الرئيسي",        type: "text",     placeholder: "وفّر ساعات من عملك يومياً" },
        { key: "HERO_SUB",    label: "وصف قصير",               type: "textarea", placeholder: "أداة ذكية تساعدك على..." },
        { key: "CTA_TEXT",    label: "نص زر الدعوة",           type: "text",     placeholder: "ابدأ مجاناً" },
        { key: "CTA_LINK",    label: "رابط الزر",              type: "url",      placeholder: "https://example.com" },
        { key: "FEATURE_1",   label: "الميزة الأولى",           type: "text",     placeholder: "سريع جداً" },
        { key: "FEATURE_2",   label: "الميزة الثانية",          type: "text",     placeholder: "سهل الاستخدام" },
        { key: "FEATURE_3",   label: "الميزة الثالثة",          type: "text",     placeholder: "آمن بالكامل" },
        { key: "FOOTER_NAME", label: "اسم الشركة/المنتج",      type: "text",     placeholder: "مؤسستي" },
      ]
    },
    {
      id: "product",
      name: "منتج رقمي",
      description: "لبيع الكورسات والمنتجات الرقمية",
      emoji: "💎",
      color: "#ff6b6b",
      file: "templates/template2.html",
      fields: [
        { key: "TITLE",         label: "عنوان الصفحة (Tab)",    type: "text",     placeholder: "كورسي المتميز" },
        { key: "PRODUCT_NAME",  label: "اسم المنتج",             type: "text",     placeholder: "كورس التسويق الرقمي" },
        { key: "TAGLINE",       label: "شعار قصير",              type: "text",     placeholder: "من صفر إلى محترف في 30 يوم" },
        { key: "DESCRIPTION",   label: "وصف المنتج",             type: "textarea", placeholder: "ستتعلم في هذا الكورس..." },
        { key: "PRICE",         label: "السعر",                  type: "text",     placeholder: "297 ريال" },
        { key: "CTA_TEXT",      label: "نص زر الشراء",           type: "text",     placeholder: "اشتري الآن" },
        { key: "CTA_LINK",      label: "رابط الشراء",            type: "url",      placeholder: "https://payment.link" },
        { key: "BONUS_1",       label: "بونص 1",                 type: "text",     placeholder: "مجموعة قوالب احترافية" },
        { key: "BONUS_2",       label: "بونص 2",                 type: "text",     placeholder: "مجتمع خاص على تيليجرام" },
        { key: "SELLER_NAME",   label: "اسم البائع/المدرب",      type: "text",     placeholder: "أحمد محمد" },
      ]
    },
    {
      id: "service",
      name: "خدمة مستقلة",
      description: "لعرض الخدمات والطلب منك مباشرة",
      emoji: "✨",
      color: "#00d9a0",
      file: "templates/template3.html",
      fields: [
        { key: "TITLE",       label: "عنوان الصفحة (Tab)",     type: "text",     placeholder: "خدماتي الاحترافية" },
        { key: "YOUR_NAME",   label: "اسمك",                   type: "text",     placeholder: "سارة العمري" },
        { key: "YOUR_ROLE",   label: "مجالك",                  type: "text",     placeholder: "مصممة جرافيك احترافية" },
        { key: "BIO",         label: "نبذة عنك",               type: "textarea", placeholder: "أساعد الشركات على بناء هويتها..." },
        { key: "SERVICE_1",   label: "الخدمة الأولى",           type: "text",     placeholder: "تصميم الهوية البصرية" },
        { key: "SERVICE_2",   label: "الخدمة الثانية",          type: "text",     placeholder: "تصميم السوشيال ميديا" },
        { key: "SERVICE_3",   label: "الخدمة الثالثة",          type: "text",     placeholder: "تصميم المطبوعات" },
        { key: "WHATSAPP",    label: "رقم واتساب (مع كود الدولة)", type: "text", placeholder: "966500000000" },
        { key: "EMAIL",       label: "البريد الإلكتروني",       type: "email",    placeholder: "me@example.com" },
      ]
    }
  ],

  // رسائل النظام
  messages: {
    authSuccess:   "✅ تم التحقق من التوكن بنجاح!",
    authFail:      "❌ التوكن غير صحيح أو منتهي الصلاحية",
    repoCreated:   "✅ تم إنشاء المستودع",
    fileUploaded:  "✅ تم رفع الصفحة",
    pagesEnabled:  "✅ تم تفعيل GitHub Pages",
    done:          "🎉 اكتمل النشر!",
  }
};
